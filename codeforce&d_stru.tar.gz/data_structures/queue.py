
#from typing import Any


class Queue:

    def __init__(self) -> None:
        self.queue_list=[]


    def push(self,new_member):
        self.queue_list.append(new_member)
        print(f"{new_member} ezafe shod -> ")

    def pop(self):
        print(f"{self.queue_list[0]} hazf shod -> ")
        return self.queue_list.pop(0)
    def __str__(self) -> str:
        return str(self.queue_list)

test1=Queue()
test1.push("A")
test1.push("B")
test1.push("C")
print(test1)
test1.pop()
test1.pop()
print(test1)