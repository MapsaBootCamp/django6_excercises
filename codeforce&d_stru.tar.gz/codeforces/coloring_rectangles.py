k_list=[]
for _ in range (int(input('enter the test case number:'))):

    n,m=list(map(int,input('enter n and m:').split()))
    matrix=n*m
    if matrix%3==0:
        k=matrix//3
        k_list.append(k)

    else:
        k=matrix//3 + 1
        k_list.append(k)
for k in k_list:
    print(k)
