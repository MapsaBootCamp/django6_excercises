from django.urls import path 
from .views import  create_test, reusalt











urlpatterns = [

    path('',create_test),
    path('show_result/<int:id>',reusalt)
   
]



