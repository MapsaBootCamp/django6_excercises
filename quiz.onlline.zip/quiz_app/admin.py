from django.contrib import admin
from django.db import models
from quiz_app.views import *
from .models import *
from .views import *
from quiz_app.models import *

# Register your models here.  


admin.site.register(Category)
admin.site.register(SoalAns)
admin.site.register(Exsam)









