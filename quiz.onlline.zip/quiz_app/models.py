from django.db import models

# Create your models here.

from django.db.models.fields import json
from django.db import models
from django.db.models.deletion import  SET_NULL

cat=(
    ("p","polotic"),
    ("s","sport"),
    ("c","culture"),
    ("e","economic"),
)



class Category(models.Model):
    cat = models.CharField(max_length=50,choices=cat)

    def __str__(self) -> str:
        return self.cat

class SoalAns(models.Model):
    category = models.ForeignKey(Category,on_delete=SET_NULL,null=True)

    test = models.CharField(max_length=255)
    optionA = models.CharField(max_length= 255)
    optionB = models.CharField(max_length= 255)
    optionC = models.CharField(max_length= 255)
    optionD = models.CharField(max_length= 255)
    ans =(

        ("optionA","A"),
        ("optionB","B"),
        ("optionC","C"),
        ("optionD","D"),
     
    )

    true_ans = models.CharField(max_length=15,choices=ans)


class Exsam(models.Model):
    
    my_ID = models.IntegerField(default=0)
    soalat = json.JSONField(null=True)


    
    
    