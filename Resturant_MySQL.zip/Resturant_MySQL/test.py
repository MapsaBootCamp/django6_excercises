from Model import BaseUser,Admin,Customer, Food
import setting
import pickle
# a=Admin('amir',12345)
# b=Customer('sara',12345678)
# b.save_baseuser()
# c=Food('kabab')
# c.save_food()

# def loadall():
#     with open(setting.Base_Dir/"UsersData"/"admin.db","rb") as file_db:
#       x=pickle.load(file_db)
#       print(x.username)

# loadall()




