import uuid

from mysql.connector import connection
import setting
import pickle


class BaseUser():
    file_name=None
    type=None
    def __init__(self,username,password):
        self.username=username
        self.password=password
        self.id=self._generate_id()

    @staticmethod
    def _generate_id():
        i=uuid.uuid4()
        return(i)

    def save_baseuser(self):
        try:
            with open(setting.Users_Data_Path/self.file_name,"ab") as db_file:
                   pickle.dump(self,db_file)
        except Exception as e:
            print(e)



class Admin(BaseUser):
     type="Admin"
     file_name="admin.db"
   

class Customer(BaseUser):
    type="Customer"
    file_name="customer.db"

class Food():
    def __init__(self,name):
        name=name

    def save_food(self):
        try:
            with open(setting.Foods_Data_Path/"food.db","ab") as f:
                   pickle.dump(self,f)
        except Exception as e:
            print(e)




# m=BaseUser('mina',12345)
# a=BaseUser('ali',123)


        
# if __name__=="__main__":
#     print(f'{m.username} {m.password} {m.id}')
#     print(f'{a.username} {a.password} {a.id}')


