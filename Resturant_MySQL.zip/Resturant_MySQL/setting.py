from os import path
import pathlib
from pathlib import Path
Base_Dir=Path(__file__).resolve().parent
print(Base_Dir)
Users_Data_Path=Base_Dir/"UsersData"
Foods_Data_Path=Base_Dir/"FoodsData"



