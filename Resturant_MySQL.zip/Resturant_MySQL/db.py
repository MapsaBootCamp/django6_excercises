import setting
import pickle
import json
import mysql.connector
db_connection=mysql.connector.connect(user='root',password='123456',host='localhost')
cursor=db_connection.cursor()
cursor.execute("create database resturant")

# def loadall(filename):
    
        
#             with open(filename,"rb") as file_db:
#                 while True:
#                     try:
#                         yield pickle.load(file_db)
#                     except EOFError as e:
#                         # print(e)
#                         break
    
# x=loadall(setting.Base_Dir/"UsersData"/"admin.db")
# print(x)
# for i in x:
#     print(i.username,i.password,i.id)
    
# def get(id:str,filename):
#     flag=False
#     x=loadall(filename)
#     for i in x:
#         if str(i.id)==id:
#             flag=True
#             print(f'{i.id} {i.username} {i.password}')
#     if flag==False:
#         print('NOt Found!')

# get("82fd86ea-1b65-4254-b451-cbc369cf0176",setting.Base_Dir/"UsersData"/"admin.db")




