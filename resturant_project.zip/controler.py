import sqlite3
from  sqlite3 import  Error 


#_______________________________________________________________________________________________________
def create_connection(db_file):
    try:
        conn=sqlite3.connect(db_file)
    except Error as e :
        print('Error in create connection :' , e)

def creat_curser(query):
    try:
        conn = sqlite3.connect('/home/barchooni/django/resturant 3/my_db.db')
        curser = conn.cursor ()
        curser.execute(query)
        conn.commit()
    except Error as e:
        print('Error in creat curser :',e)

create_connection('/home/barchooni/django/resturant 3/my_db.db')
#________________________________________________________________________________________________________

###  menu and food tables  ###

def create_table_food ():
    try:
        query='create table if not exists food (id integer , food_name varchar(100),price float ,active varchar(20))'
        creat_curser(query)
    except Error as e:
        print('Error in create table food :',e)
create_table_food()

def add_food(id,food_name,price,active):
    try:
        query=f"insert into food (id,food_name,price,mojudi)values('{id}','{food_name}','{price}','{active}')"
        creat_curser(query)
    except Error as e:
        print('Error in add food :',e)
#_________________________________________________________________________________________________________

### customers_info  ###
def create_table_customers ():
    try:
        query='create table if not exists customers (name varchar(100),last_name varchar(100),phone_number integer)'
        creat_curser(query)
    except Error as e:
        print('Error in create table customers :',e)
create_table_customers()

def add_customer(name,last_name,phone_number):
    try:
        query=f"insert into customers (name,last_name,phone_number)values('{name}','{last_name}','{phone_number}')"
        creat_curser(query)
    except Error as e:
        print('Error in add customer :',e)
#_________________________________________________________________________________________________________


class Menu:
    def view(self):
        pass
    def update(self):
        pass
class Customer_info:
    pass

