from  controler import add_customer , add_food

class Login_m:
    def __init__(self , username  , password  , type  ) -> None:
        self.username = username 
        self.password = password
        self.type = type 

class View_data:
    pass
class Add_data:
    def add_food(food_id,food_name,food_price,food_activation):
        add_food(food_id,food_name,food_price,food_activation)
    def add_customers(name,last_name,phone_number):
        add_customer(name,last_name,phone_number)


