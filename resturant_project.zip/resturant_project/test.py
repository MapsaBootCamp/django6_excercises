from models import Admin,Customer,Foods
import db
import contoroller
# import app
#import bcrypt

# a=Admin("ali","22")
# a.save()



# b=Customer("mehdi","16")
# b.save()


# for i in Customer.db_obj.loadall():
#     print(i.username)

#     print(bcrypt.checkpw("22", i.password))



    
# c=Foods("shalgham","10000","200","har pors 5 add darad")
# # c.save()
# for i in Foods.db_obj.loadall():
#     i.__dict__["mojodi"]="199"
#     print(i.__dict__)

# print (contoroller.signin("sobasa",3))

# print(contoroller.signin_check_customer("ali","22"))


# for i in Customer.db_obj.loadall():
#     print(i.username)