from pathlib import Path

Base_Dir=Path(__file__).resolve().parent

User_Dir=Base_Dir / "User_db"
Food_Dir=Base_Dir / "Food_db"
Gozaresh_Dir=Base_Dir/"Gozaresh_db"


