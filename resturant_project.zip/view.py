from controler import *
from model import Add_data
from colorama import Fore, Back, Style

class Login_v():
    #____________________________________________
    def preview(self):
        if input(Fore.YELLOW + '''
        welcom to resturant
        You aren't logged in.press 1 to log in for book food and view the menu! or press any key for exit :
        ''').strip() == '1':
            take_login_info = Login_v()
            take_login_info.login_info()
        else:
            exit('bye bye!')
    #____________________________________________   
    def login_info (self):
        type = input(Fore.RESET + '''
        what's your type?
        1)admin
        2)customer
        Enter the number : ''')
        username = input('Enter your username :').lower().strip()
        password = input('Enter your password:').lower().strip()
        if type == '1':
            if username == 'root' and password == 'admin':
                show_pannel = Login_v()
                show_pannel.admin_pannel()
            else:
                print(Fore.RED+'uncorrect username or password!')
                run_again = Login_v()
                run_again.login_info()

        elif type == '2':
            if username == 'customer' and password == 'lollipop':
                show_pannel = Login_v()
                show_pannel.customer_pannel()
            else:
                exit(Fore.RED+'uncorrect username or password!')
        else:
            exit('Enter the number correctly!')
    #____________________________________________
    def admin_pannel(self):
        a = input(Fore.GREEN + '''
        Hi admin!
        1)view menu
        2)add to menu
        3)view and edit customers list
        Enter the number :''')

        if a == '1':
            print(Fore.RED+'Not completed!')
            #SELECT food_id,food_name,food_price,food_activation FROM food
            pass
        if a == '2':
            while input('do you wanna add food into menu? press 1 for yes and any key for no.') == "1":
                    def menu():
                        food_id=input('please enter food id :')
                        food_name=input('please enter food name :')
                        food_price=input('please enter food price :')
                        food_activation=input('please enter food activation :')
                        print('done')
                        Add_data.add_food(food_id,food_name,food_price,food_activation)
                    menu()
        if a == '3':
            print(Fore.RED+'Not completed!')
            pass

    #____________________________________________
    def customer_pannel (self):
        print(Fore.GREEN+'''
        Hi user!
        plesae complete you'r profile''')
         
        def customers_list():
            name = input('Enter your name :')
            last_name = input('Enter your last name :')
            phone_number = input('Enter your phone number :')
            print('done')
            if input(f'''
            name : {name} , last name : {last_name} , phone number : {phone_number}
            Is the above information correct? press 1 for yes and any key for no.
            ''') == '1':
                Add_data.add_customers(name,last_name,phone_number)
                a = input('If you want to order food, enter the food code And otherwise enter 1:  ') 
                if a == '1':
                    exit('bye bye')
                else:
                    orders = [a]
                    print (a)
                    while input('Do you have another order? press 1 for yes and any key for no.') == '1':
                        orders.append(input('enter the food code :'))
                        print(orders)
                    print(Fore.RED+'done. Continue the order registration process is not complete.')

            else:
                run_again = Login_v()
                run_again.customer_pannel()
        
        customers_list()





        
    #____________________________________________




    






run = Login_v()
run.preview()