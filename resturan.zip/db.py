import model
import mysql.connector

data_list=[]
def input_data():
    name=input('pleas enter your fullname:')
    passwrd=int(input('enter your password Maximum 5 charector:'))
    data_list.append(name)
    data_list.append(passwrd)
    return(data_list)

class Query(object):
    
    cnx = mysql.connector.connect(user='asal', password='asal.1651374',
                                        host='localhost',
                                        database='resturant')
    def sign_up(self):  
        user_data=(self.username,self.password,self.type,
        self.id)
        add_customer="INSERT INTO users (username, password, type, id) VALUES (%s, %s, %s, %s);"
        cursor=Query.cnx.cursor(prepared=True)
        cursor.execute(add_customer , user_data)
        Query.cnx.commit()

    def login(self):
        user_data=(self.username,self.password)
        login_data="SELECT  username , password FROM users WHERE (username = '%s' ,pasword= %s);"
        cursor=Query.cnx.cursor(buffered=True)
        cursor.execute(login_data , user_data)
        Query.cnx.commit()
        row = cursor.fetchone()
        if row:
            print('')




    def create_table():
        query='''create table if not exists users
       (username varchar(20), password varchar(90), type varchar(10),id varchar(60))'''
        cursor=Query.cnx.cursor()
        cursor.execute(query)
        Query.cnx.commit()

        query='''create table if not EXISTS admins
        (username varchar(20), password varchar(90), type varchar(10),id varchar(60))'''
        cursor=Query.cnx.cursor()
        cursor.execute(query)
        Query.cnx.commit()

        query='''create table if not EXISTS food
        (id int ,foodname varchar(20),price int,info varchar(200))'''
        cursor=Query.cnx.cursor()
        cursor.execute(query)
        Query.cnx.commit()

        query='''create table if not EXISTS orderd
        (id_food int, foodname varchar(20) , customer varchar(20))'''
        cursor=Query.cnx.cursor()
        cursor.execute(query)
        Query.cnx.commit()


    def  Food_query ():
        cursor=Query.cnx.cursor()
        query="SELECT * FROM food;"
        cursor.execute(query)
        row = cursor.fetchall()
        for item in row:
            print(item)


    def add_to_card( username,order=None):
         cursor=Query.cnx.cursor(prepared=True)
         query="INSERT INTO orderd (id_food ,customer ) values(%s ,%s) "
         add_data=(order ,username )
         cursor.execute(query , add_data)
         Query.cnx.commit()
         


    def show_history():
        cursor=Query.cnx.cursor()
        query="SELECT foodname FROM food INNER JOIN orderd ON food.id =orderd.id_food"
        cursor.execute(query)
        row = cursor.fetchall()
        for item in row:
            print(item)
    
    def customer_purches():
        cursor=Query.cnx.cursor()
        query='''SELECT food.food_name ,FROM Orderd'''
        '''INNER JOIN users on orderd.customer= users.username'''
        cursor.execute(query)
        row = cursor.fetchall()
        for item in row:
            print(item)

    

    def add_to_menu(food_data):
        cursor=Query.cnx.cursor()
        query="insert into food(id , foodname , price , info) values ('%s', '%s' ,'%s' , '%s')"
        cursor.execute(query , food_data)
        Query.cnx.commit()


    def remove_from_menu(food_data):
        cursor=Query.cnx.cursor()
        query=" delet from food where foodname='%s' "
        cursor.execute(query , food_data)
        Query.cnx.commit()

    



                        





    

