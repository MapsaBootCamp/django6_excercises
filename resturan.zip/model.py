from uuid import uuid4
from hashlib import sha256
import mysql.connector
import mysql
from db import *




class BaseUser(object):
    type=None
    data=None
    db_table=None

    def __init__(self, username, password) -> None:
        self.username = username
        self.password = self._set_password(password)
        self.id = self._generate_id()

    @staticmethod
    def _generate_id():
        return str(uuid4())


    @staticmethod
    def _set_password(passw):
        hash_passw= sha256(b'%d'% passw).hexdigest()
        return hash_passw


   



class Admin(BaseUser):
    type='admin'
       


class Customer(BaseUser):
    type='customer'
    reserve=None

    


class FoodMenu():
    pass