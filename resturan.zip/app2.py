

import logging
from model import Admin
from db import *


Query.create_table()

print('*********************welcome to my fastfood*********************')

ans=input('if you are admin press 1 \nif you are customer press 2:')
if ans=='1':
    input_data()
    admin=model.Admin(data_list[0],data_list[1])
    Query.login(admin)
    
    ans=input('add food in menu press 1 \n remove food from menu press 2\n see customers info press 3')
    if ans=='1':
        Query.add_to_menu()
    elif ans=='2':
        Query.remove_from_menu()
    else:
        Query.show_history()
else:   
    ans=input('sign in/sign up:')
    if ans=='sign up':
        input_data()
        customer=model.Customer(data_list[0],data_list[1])
        Query.sign_up(customer)
    else:
        input_data()
        customer=model.Customer(data_list[0],data_list[1])
        Query.login(customer)
        
    ans=input('to see menu and reserve food press 1\n to see purchase history press 2:')
    if ans=='1':
        Query.Food_query()
        order=input('To make a reservation, please enter the food ID: ')
        Query.add_to_card(customer.username,order)
    else:
        Query.customer_purches()





