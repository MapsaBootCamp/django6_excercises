tedad = int(input('bgo : '))

while tedad:
    horof = input('bgo horof made nazareto : ')
    kalame = input('bgo kalame made nazareto : ')
    counter = 0
    for i in range(len(kalame)-1):
        counter += abs(horof.index(kalame[i]) - horof.index(kalame[i+1]))
    print(counter)
    tedad -= 1
    
    
    #i dont solve this practice
    
    
    