def Era(khode_array):
    tol_array = int(input('tole araye morede nazar? : '))
    for i in range(tol_array):
        khode_array[i] -= i + 1
    return max(khode_array + [0])


if __name__ == "__main__":
    print(Era([1, 3, 4]))



#in practice give a number and with split slide by slide give a number 







    
for i in range(int(input())):
    n = int(input(' '))
    a = list(map(int , input().split()))
    s = 0
    for i in range(n):
        s = max(s, a[i] -i -1)
    print(s)
    
    





