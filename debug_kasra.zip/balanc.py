
#code kasra




# Str = str(input('string mad nazar : '))


# def Balance(Str):
#     my_list = list(Str)
#     for i in range(len(my_list)):
#         if Str[0] == Str[-1::]:
#             return Str
#         else:
#             if Str[0] != "ab":
#                 my_list[0] = "b"
#             elif Str[-1::] != "ba":
#                 my_list[-1::] = "a"
#     return my_list


# if __name__ == "__main__":
#     print(Balance(Str))
    
#  #debugcode
 
    
#تو این مثال دنبال اینه که تا رشته ی یدونه مونده به اخر چاپ کنه و اخرین کارکتر بشه اولین کارکتر 

tedad = int(input(''))
for i in range (tedad):
    s = input()
    print(s[:-1] + s[0])
    
    
       
    
    
    
    
    
    
    
