def blueRed(array=[], rang=[]):
    tol = int(input('tol e array o bego : '))
    while tol:
        array.append(int(input('adad made nazar : ')))
        tol -= 1
    ye_adadi = len(array)
    while ye_adadi:
        rang.append(str(input('ye rangi beyne b ya r : ')))
        ye_adadi -= 1
    new_array = array
    print(array)
    print(rang)
    ye_adadi_1 = len(rang)
    while ye_adadi_1:
        jaygasht = int(input('bego kodom jaygah o mikhay taghir bedi (tebghe index): '))
        if 'b' in rang[jaygasht]:
            new_array[jaygasht] -= 1
        elif 'r' in rang[jaygasht]:
            new_array[jaygasht] += 1
        ye_adadi_1 -= 1
    print(new_array)
    for i in range(len(new_array)):
        if i+1 == new_array[i]:
            print("YES")
        else:
            print("NO")


if __name__ == "__main__":
    print(blueRed())


#این مثال رو دقیق متوجه نشدم اما میدونم اشتباه کد زده شده 


