def malakh(mokhtasat, paresh):
    distance = 1
    while paresh > 0:
        if not mokhtasat % 2:
            new_mokh = mokhtasat - distance
        else:
            new_mokh = mokhtasat + distance
        mokhtasat = new_mokh
        distance += 1
        paresh -= 1
    return new_mokh


if __name__ == "__main__":
    print(malakh(5220093230, 1003230))
    
    
    
    
    
#to in mesal bayad masafati ke dare mire +- range oon add beshe


    
# ra= int(input())
# for i in range(ra):
#     a , b = map(int, input().split())
#     ans = a
#     answer =[]
#     for i in range(b - (b % 4) + 1, b + 1):
#         if ans % 2 == 0:
#             ans -= i
#             answer.append(ans)
#         else:
#             ans += i
#             answer.append(ans)
            
# print(answer)
    