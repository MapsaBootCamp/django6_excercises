from django.urls import path
from .views import  show_answers, show_questions
urlpatterns = [
    path('Quiz/<str:name>',show_questions,show_answers),
    #path("Karname/<str:name>)
]
