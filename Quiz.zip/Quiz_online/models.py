from django.db import models
from django.db.models.deletion import DO_NOTHING
from django.db.models.fields.related import ForeignKey


# Create your models here

class Category(models.Model):
    CATEGORY_CHOICES=[
            ("sp","SPORT"),
            ("si","SIENCE"),
            ("ec","ECONOMIC"),
            ("po","POLITIC"),
            ("cu","CULTURAL")
            ]
    title=models.CharField(null=True,max_length=2,verbose_name=("title"),choices=CATEGORY_CHOICES)

    def __str__(self) -> str:
        return self.title or ''


class Question(models.Model):
    Category = models.ForeignKey(Category, on_delete=models.CASCADE)
    title = models.TextField( verbose_name="title")

    def __str__(self):
        return self.title or ""


class Answer(models.Model):
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    true_false = models.BooleanField(blank=True, null=True)
    opt = models.CharField(max_length=300)

    def __str__(self):
        return f"{self.question} - {self.true_false} - {self.opt}"


class Student(models.Model):
    name = models.CharField(max_length=200, unique=True,verbose_name=("name"))

    def __str__(self):
        return self.name

class karname(models.Model):
    name = ForeignKey(Student, on_delete=DO_NOTHING)
    barom = models.IntegerField(default=0,null=True)
    quiz=models.JSONField(null=True)

    def __str__(self):
        return self.name or ''