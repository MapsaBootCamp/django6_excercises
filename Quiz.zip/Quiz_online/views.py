from django.shortcuts import render 
from .models import  Answer, Question
import json
from django.http.response import JsonResponse
from django.views.decorators.csrf import csrf_exempt
#from django.db.models import Q
#import random


@csrf_exempt
def show_questions(request,name):
    qs = Question.objects.all().values()
    return JsonResponse(qs,safe=True)

@csrf_exempt
def show_answers(request):
    qs = Answer.objects.all().values()
    return JsonResponse(qs, safe=True)