from django.apps import AppConfig


class QuizOnlineConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Quiz_online'
