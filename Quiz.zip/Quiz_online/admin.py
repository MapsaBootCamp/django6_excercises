from django.contrib import admin

# Register your models here.
from .models import Category, Student, Question, Answer,karname

admin.site.register(Category)
admin.site.register(Student)
admin.site.register(Question)
admin.site.register(Answer)
admin.site.register(karname)
